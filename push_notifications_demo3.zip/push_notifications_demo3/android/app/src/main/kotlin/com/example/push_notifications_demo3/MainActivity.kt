package com.example.push_notifications_demo3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
